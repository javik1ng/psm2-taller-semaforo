/* Includes ------------------------------------*/
#include "main.h"

/* Private define------------------------------ */
#define TIEMPO_ROJO_MS 3000          // Tiempo en rojo (3 segundos)
#define TIEMPO_PARPADEO_MS 200       // Intervalo de parpadeo (200 ms)
#define CICLOS_PARPADEO_TOTAL 5      // Total de alternancias para 1 segundo de parpadeo

/* Private variables ---------------------------------------------------------*/
typedef enum {
    ESTADO_VERDE,
    ESTADO_PARPADEO_VERDE,
    ESTADO_ROJO,
    ESTADO_PARPADEO_ROJO
} EstadoSemaforo;

EstadoSemaforo estado_actual = ESTADO_VERDE;
uint32_t tiempo_inicio = 0;
uint32_t tiempo_parpadeo = 0;
uint8_t contador_parpadeo = 0;       // Contador para el número de parpadeos

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
void cambiar_a_rojo(void);
void cambiar_a_verde(void);
void iniciar_parpadeo_verde(void);
void iniciar_parpadeo_rojo(void);
void manejar_parpadeo_verde(void);
void manejar_parpadeo_rojo(void);
uint32_t millis(void);  // Función para obtener el tiempo actual en ms

/* MAIN START----------------------------------------------------------------------*/
int main(void) {
    /* MCU Configuration-------------------------*/
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();

    /* Configurar estado inicial: verde encendido */
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_RESET);   // Encender verde (PB12)
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);     // Apagar rojo (PC13)

    /* Bucle infinito */
    while (1) {
        // Leer estado del botón PB5 (Botón 1)
        GPIO_PinState boton1_estado = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_5);

        // Controlar el estado del semáforo
        switch (estado_actual) {
            case ESTADO_VERDE:
                if (boton1_estado == GPIO_PIN_SET) {
                    iniciar_parpadeo_verde();  // Iniciar el parpadeo del verde
                }
                break;

            case ESTADO_PARPADEO_VERDE:
                manejar_parpadeo_verde();  // Gestionar el parpadeo del verde
                break;

            case ESTADO_ROJO:
                if (millis() - tiempo_inicio >= TIEMPO_ROJO_MS) {
                    iniciar_parpadeo_rojo();  // Iniciar parpadeo del rojo antes de cambiar a verde
                }
                break;

            case ESTADO_PARPADEO_ROJO:
                manejar_parpadeo_rojo();  // Gestionar el parpadeo del rojo
                break;
        }
    }
}
/* END MAIN -----------------------------------------------------------------*/

/* Funciones auxiliares ------------------------------------------*/
void iniciar_parpadeo_verde(void) {
    estado_actual = ESTADO_PARPADEO_VERDE;
    tiempo_inicio = millis();
    tiempo_parpadeo = millis();
    contador_parpadeo = 0;  // Reiniciar el contador de parpadeo
}

void manejar_parpadeo_verde(void) {
    // Apagar o encender el LED verde en cada intervalo de 200 ms
    if (millis() - tiempo_parpadeo >= TIEMPO_PARPADEO_MS) {
        if (contador_parpadeo % 2 == 0) {
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_SET); // Apagar verde
        } else {
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_RESET); // Encender verde
        }
        tiempo_parpadeo = millis();  // Reiniciar el temporizador para el siguiente cambio
        contador_parpadeo++;  // Incrementar el contador de alternancias
    }

    // Cambiar a rojo después de 5 alternancias (1 segundo total de parpadeo)
    if (contador_parpadeo >= CICLOS_PARPADEO_TOTAL) {
        cambiar_a_rojo();
    }
}

void iniciar_parpadeo_rojo(void) {
    estado_actual = ESTADO_PARPADEO_ROJO;
    tiempo_inicio = millis();
    tiempo_parpadeo = millis();
    contador_parpadeo = 0;  // Reiniciar el contador de parpadeo
}

void manejar_parpadeo_rojo(void) {
    // Apagar o encender el LED rojo en cada intervalo de 200 ms
    if (millis() - tiempo_parpadeo >= TIEMPO_PARPADEO_MS) {
        if (contador_parpadeo % 2 == 0) {
            HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET); // Apagar rojo
        } else {
            HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET); // Encender rojo
        }
        tiempo_parpadeo = millis();  // Reiniciar el temporizador para el siguiente cambio
        contador_parpadeo++;  // Incrementar el contador de alternancias
    }

    // Cambiar a verde después de 5 alternancias (1 segundo total de parpadeo)
    if (contador_parpadeo >= CICLOS_PARPADEO_TOTAL) {
        cambiar_a_verde();
    }
}

void cambiar_a_rojo(void) {
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_SET);    // Apagar verde
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);  // Encender rojo
    tiempo_inicio = millis();
    estado_actual = ESTADO_ROJO;
}

void cambiar_a_verde(void) {
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);    // Apagar rojo
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_RESET);  // Encender verde
    estado_actual = ESTADO_VERDE;
}

/* Función para obtener el tiempo actual en milisegundos */
uint32_t millis(void) {
    return HAL_GetTick();  // Usar el tick del sistema de HAL
}

/* Configuración del reloj */
void SystemClock_Config(void) {
    // Configuración del reloj del sistema
}

/* Inicialización de GPIO */
static void MX_GPIO_Init(void) {
    // Configurar los pines de los LEDs y los botones
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    // Habilitar el reloj para los puertos B y C
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();

    // Configurar LED verde (PB12)
    GPIO_InitStruct.Pin = GPIO_PIN_12;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    // Configurar LED rojo (PC13)
    GPIO_InitStruct.Pin = GPIO_PIN_13;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    // Configurar Botón 1 (PB5)
    GPIO_InitStruct.Pin = GPIO_PIN_5;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLDOWN;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}
